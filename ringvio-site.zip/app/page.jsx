
"use client";

import { useEffect } from "react";
import Swiper from "swiper";
import "swiper/css";

export default function Home() {
  useEffect(() => {
    new Swiper(".swiper-container", {
      loop: true,
      autoplay: { delay: 3000, disableOnInteraction: false },
      slidesPerView: 1,
      spaceBetween: 30,
      pagination: { el: ".swiper-pagination", clickable: true },
    });
  }, []);

  return (
    <div className="bg-gray-100 font-sans text-gray-800">
      {/* Header, Hero, Features, About, Contact, Footer sections go here */}
      <h1 className="text-center p-20">Ringvio Homepage</h1>
    </div>
  );
}
